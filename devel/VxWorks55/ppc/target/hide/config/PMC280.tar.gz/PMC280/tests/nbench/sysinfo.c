
#include "stdio.h"

sprintf(outBuffer,"**System used for compilation:\n");
output_string(outBuffer);
sprintf(outBuffer,"**SunOS chronos 5.9 Beta sun4u sparc SUNW,Ultra-5_10\n");
output_string(outBuffer);
sprintf(outBuffer,"**C compiler: dcc (unknown version)\n");
output_string(outBuffer);
sprintf(outBuffer,"**libc: unknown version\n");
output_string(outBuffer);
sprintf(outBuffer,"**Date of compilation: Mon Apr 22 13:42:47 MEST 2002\n");
output_string(outBuffer);
