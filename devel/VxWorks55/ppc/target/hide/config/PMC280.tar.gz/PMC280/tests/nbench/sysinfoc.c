#include <stdio.h>

sprintf(outBuffer,"C compiler          : dcc (unknown version)\n");
output_string(outBuffer);
sprintf(outBuffer,"libc                : unknown version\n");
output_string(outBuffer);
