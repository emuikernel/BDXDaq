//////////////////////////////////////////////////////////////////////////
//                                                                      //
// CMVirtualDisplay                                                     //
//                                                                      //
// Virtual base class for Moller Polarimeter display                    //
//                                                                      //
//////////////////////////////////////////////////////////////////////////

#include "CMVirtualDisplay.h"

ClassImp(CMVirtualDisplay)


//_____________________________________________________________________________
CMVirtualDisplay::CMVirtualDisplay() : TObject()
{
}

//_____________________________________________________________________________
CMVirtualDisplay::~CMVirtualDisplay()
{

}

