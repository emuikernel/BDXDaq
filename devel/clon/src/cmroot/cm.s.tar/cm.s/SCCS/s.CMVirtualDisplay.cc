h60546
s 00024/00000/00000
d D 1.1 06/10/19 15:41:14 boiarino 1 0
c date and time created 06/10/19 15:41:14 by boiarino
e
u
U
f e 0
t
T
I 1
//////////////////////////////////////////////////////////////////////////
//                                                                      //
// CMVirtualDisplay                                                     //
//                                                                      //
// Virtual base class for Moller Polarimeter display                    //
//                                                                      //
//////////////////////////////////////////////////////////////////////////

#include "CMVirtualDisplay.h"

ClassImp(CMVirtualDisplay)


//_____________________________________________________________________________
CMVirtualDisplay::CMVirtualDisplay() : TObject()
{
}

//_____________________________________________________________________________
CMVirtualDisplay::~CMVirtualDisplay()
{

}

E 1
